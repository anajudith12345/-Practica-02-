package com.example.http_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
